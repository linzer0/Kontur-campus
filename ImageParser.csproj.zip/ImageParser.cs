using System.IO;

namespace ImageParser
{
    public class ImageParser : IImageParser
    {
        public string GetImageInfo(Stream stream)
        {
            throw new System.NotImplementedException();
        }
    }
}